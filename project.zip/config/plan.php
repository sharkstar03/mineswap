<?php

return [
    'period' => [
        'Day(s)' => "1",
        'Week(s)' => "7",
        'Month(s)' => "30",
        'Year(s)' => "365",
    ],

    'hash_rate'=>[
        0 =>"Hash/s",
        1 =>"Khash/s",
        2 =>"Mhash/s",
        3 =>"Ghash/s",
        4 =>"Thash/s",
        5 =>"Phash/s",
        6 =>"Ehash/s",
        7 =>"Zhash/s",
        8 =>"Yhash/s",
    ]


];










