<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'mining, bitcoin, blockchain, coin, crypto, cryptocurrency, dogecoin, ethereum,  forex, HYIP, ico, trading, bank, miner, cloud mining',
  'meta_description' => 'MineStack -   A Digital Mining Platform',
  'social_title' => 'MineStack -   A Digital Mining Platform',
  'social_description' => 'MineStack -   A Digital Mining Platform',
);