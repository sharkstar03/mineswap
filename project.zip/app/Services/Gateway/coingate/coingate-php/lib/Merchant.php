<?php

namespace CoinGate;

class Merchant
{
}
